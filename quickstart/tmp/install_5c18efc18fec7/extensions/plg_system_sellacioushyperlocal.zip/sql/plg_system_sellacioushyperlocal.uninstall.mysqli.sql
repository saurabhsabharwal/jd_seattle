-- --------------------------------------------------------
-- Uninstall Database: `plg_system_sellacioushyperlocal`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `#__sellacious_seller_hyperlocal`;

DROP TABLE IF EXISTS `#__sellacious_seller_timings`;

DROP TABLE IF EXISTS `#__sellacious_cache_distances`;
