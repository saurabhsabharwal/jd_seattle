<?php
/**
 * @version     1.6.0
 * @package     Sellacious Seller Products Module
 *
 * @copyright   Copyright (C) 2012-2018 Bhartiy Web Technologies. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Mohd Kareemuddin <info@bhartiy.com> - http://www.bhartiy.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

require(JModuleHelper::getLayoutPath('mod_sellacious_sellerproducts', 'grid'));
