DROP TABLE IF EXISTS `#__importer_templates`;
DROP TABLE IF EXISTS `#__importer_template_usercategories`;
