-- --------------------------------------------------------
-- Uninstall Database: `com_sellaciousreporting`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `#__sellacious_reports`;

DROP TABLE IF EXISTS `#__sellacious_reports_permissions`;
