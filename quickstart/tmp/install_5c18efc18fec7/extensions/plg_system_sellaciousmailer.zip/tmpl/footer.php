<?php
/**
 * @version     1.6.0
 * @package     sellacious
 *
 * @copyright   Copyright (C) 2012-2018 Bhartiy Web Technologies. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Izhar Aazmi <info@bhartiy.com> - http://www.bhartiy.com
 */
// defined('_JEXEC') or die;
?>
<div style="clear: both;"></div>
<div style="text-align: center;"><a href="https://www.sellacious.com" style="text-decoration: none;">
	<span style="font-size: 10px;">Powered by: Sellacious</span><br><img
		style="width: 100px; height: 20px; margin: 4px auto;"
		src="https://www.sellacious.com/images/releases/sellacious-mail-footer-icon.png"/></a>
</div>
<div style="clear: both;"></div>
