DROP TABLE IF EXISTS `#__languages_strings`;

